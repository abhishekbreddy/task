

import './App.css';
import React, { Component } from 'react';
import Axios from 'axios'
import logo from './logo.svg'



import '../node_modules/bootstrap/dist/css/bootstrap.min.css'


    
     

class App extends Component {
    constructor(props) {
        super(props)
    
        this.state = {
             data:[]
        }
    }
    
    componentDidMount() {
       Axios.get("https://www.reddit.com/r/reactjs.json").then((response)=>{
           console.log(response.data.data)
           this.setState({
               data:response.data.data.children
           })
       })
    }
    render() {
        return (
          <div className="App">
                <div className="container">
                    <div className="card">
                        <div className="card-header text-blue">
                            <img src={logo} style={{width:"50px",height:"50px"}}/>
                             <h2>Challenge Title</h2>
                        </div>
                        <div className="card-body text-center">
                    
                    <div className="row">
                    
                  .
                {
                    this.state.data && this.state.data.map((data)=>{
                                          return (
                                              <>
                                             
                                              <div className="col-sm-5 mt-5">
                                                  <div className="d-{inline} bg-light text-white">
                                                      <div className="card body bg-dark">
                                                          <label className="font-weight-bold" style={{color:"black",fontStyle:"bold"}}>Title : </label>&nbsp;&nbsp;{data.data.title}<br />
                                                          <label className="font-weight-bold" style={{color:"black",fontStyle:"bold"}}>URL : </label>&nbsp;&nbsp;{data.data.url}<br />
                                                          <label className="font-weight-bold" style={{color:"red",fontStyle:"bold"}}>Score : </label>&nbsp;&nbsp;{data.data.score}<br />
                                                          <label className="font-weight-bold" style={{color:"black",fontStyle:"bold"}}>SelfText_HTML : </label>&nbsp;&nbsp;{data.data.selftext_html}<br />
                                                        
                                                     
                                                      </div>
                                                  </div>
                                              </div>
                                              </>
                                          )
                    })
                }
                </div>
                </div>
            </div>
            </div>
                </div>
        );
    }
}


   

export default App;
